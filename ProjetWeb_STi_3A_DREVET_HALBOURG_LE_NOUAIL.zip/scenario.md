# Scénario utilisateur

Liens : https://www.testapic.com/informations-pratiques/actualites/design-conception/ameliorer-votre-experience-utilisateur-grace-aux-scenarios-utilisateurs/

**Qui est l'utilisateur pour qui je conçois le site ? Qu'est-ce que l'utilisateur veut sur mon site?**
Une personne ayant très peu d’expérience avec le numérique veut accéder à notre site pour avoir un cours informatique sur un sujet précis. Ce sujet est comment créer un compte sur YouTube et comment pouvoir écouter de la musique chez elle ensuite sur une enceinte.
Il souhaite accéder rapidement au cours qu’il veut en arrivant sur le site. Il espère également trouver de l’aide s’il a un problème par rapport au cours donné. Cette personne est également capable de donner un peu d’argent si les cours sont vraiment bien fait.

**Comment l'utilisateur va-t-il atteindre ses objectifs?**
Très peu familière avec le numérique, cette personne s’attend à ce que le site soit simple d’utilisation et espère trouver rapidement la réponse à son problème sans passer des heures sur Internet. 

**Pourquoi cet utilisateur arrive-t-il sur mon site et pas ailleurs ?**
Cette personne arrive sur notre site car une sa grand-mère lui a conseillé le site. En effet cette dernière à trouver le site relativement facile et adapter à ses besoin lorsqu’elle a eu besoin d’un cours sur « comment créer une adresse mail personnelle ? ». De plus, pour l’instant cette personne ne veut pas encore engagé de l’argent pour un cours particulier c’est pourquoi elle trouve plus simple de chercher dans un premier temps sa réponse sur Internet. 
