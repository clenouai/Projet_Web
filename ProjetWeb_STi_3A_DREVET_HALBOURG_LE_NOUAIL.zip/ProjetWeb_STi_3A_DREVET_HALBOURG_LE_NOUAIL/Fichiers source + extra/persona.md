# Persona : client idéal, notre cible
source : https://www.easybear.fr/blog/comment-creer-persona

## Personalité et préférences de notre cible:
Aime apprendre de nouvelles choses, 
aime vivre, 
vit avec son temps(numérique), 
fait parti d'associations (avec lequelles elle a besoin de communiquer numériquement)
s'intéresse à la politique et à l'actualité (besoin d'information numérique)

##Physique:
Personne agée (60ans et plus), 
femme ou homme, 
a des petits enfants (avec eux ils sont déjà sensibilisés à l'informatique),  

## Son histoire: 
Prénom: Michelle,
Née en France,
région ??
grandit dans la ville 
ses parents étaient: ??
scolarisée jusqu'à l'âge de 16 ans chez les soeur.
Frère et soeur : 2 frères, 3 soeurs, elle est l'aîné
Education:
  adorait les maths
  elle a soif de nouvelles connaisances
  bcp d'amis
  études jusqu'â 16 ans   ????
 Parcours pro:
  premier travail à 16 ans
  profession endroit où il y avait très peu de matériels numériques
  actuellement à la retraite
 Situation personnelle:
  elle vit en bordure de la ville dans une maison avec son mari.
  bien dans sa peau, bien dans sa vie,
  proche de sa famille ( besoin de communiqué par skype, etc. peut être ? )
  pas d'animaux
 Situation financière:
  se porte bien financièrement (achat d'ordinateur)
 Vie privée:
 
 Sentiments, motivations :
 
 Informations commerciales :
    souhaite se former au niveau numérique sur la création d'un site skype et de son utilisation pour communiquer avec sa famille et ses amis
    souhaite savoir envoyé des pieces jointes dans un mail 
    préfère toute de mêm communiquer à l'ancienne (téléphone)
    pas totalement en confiance avec la sécurité au niveau internet (paiement + données perso)
   

    
  
