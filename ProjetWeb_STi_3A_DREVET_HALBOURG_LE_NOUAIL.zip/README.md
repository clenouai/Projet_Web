# Projet_Web
Projet d'Ingénierie Web

Création d'un site web d'apprentissage et d'aide aux personnes agées.

*ITStarterCourses*
## Apprenez en toute simplicité

## Objectifs:

### Structure free:

#### Cours technique : 
Fonctions de base (par vidéos et textes) tel que créer son adresse-mail, envoie de mails avec pièces jointes, sensibilisation à la sécurité, installer imprimante, recherche web, utilisation matériel physique (usb) et système (fond d'écran, création de dossiers), leur faire connaître les différents logiciel pour texte, tableau (excel), utilisation de notre forum/chat.

#### Cours de sensibilisation : 
Comment choisir un bon mot de passe, comment ne pas se faire avoir sur internet (Hammeçonnage,..)
Hiérarchiser nos cours ??

### Structure payante:
Structure prémium: cours payants, cours personalisés, aide informatique à domicile.

Les utilisateurs du site pourront créer un compte avec identifiant/mdp. Pour accéder à la structure de payante, celui-ci doit obligatoirement posséder un compte.

Forum/chat : mise en relation des personnes agées, et avec des professionnels. 

